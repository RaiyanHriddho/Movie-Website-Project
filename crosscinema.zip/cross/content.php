<?php 

include'header.php';

 ?>




 <?php 

include 'ft.php';
include 'sidebar.php';

  ?>